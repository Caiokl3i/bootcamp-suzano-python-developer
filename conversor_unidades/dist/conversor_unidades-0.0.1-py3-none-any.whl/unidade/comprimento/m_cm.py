def metros_centimetros(comprimento):
    return comprimento * 100

def centimetro_metros(comprimento):
    return comprimento / 100